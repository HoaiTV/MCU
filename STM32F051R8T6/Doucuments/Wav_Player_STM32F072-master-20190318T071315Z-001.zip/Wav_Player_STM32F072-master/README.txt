/********************************************/
/* Filename: README.txt */
/* Author: Lee.HJ */
/* Time 2015年 3月31日 星期二 22时34分59秒 CST  */
/********************************************/

	The project which must running in the stm32f072 board is my first embe--dded program. It is a media player which can play .wav file. Because of the board has no SD card and the Flash is only 128Kb, the size of the media file can't overstep 90Kb. I will improve this module in next version.

	How to use it?
	You neet to open the USER folder and open Usart.uvprojx with Keil. 
	That's all, than you ^_^
