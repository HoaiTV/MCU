/******************************************************************************** 
Bkav
Product: 
Module: buzz service
Version: 1.0
Author: dinhlk
Created: 
Modified: 
<Name>
<Date>
<Change>
Released: <Date>
Description: <Description>
Note: <Note>
********************************************************************************/
#ifndef __BUZZ_H__
#define __BUZZ_H__

VOID InitBuzz();

VOID BuzzSet( BYTE nIndex);
#endif /*BUZZ_H_*/
