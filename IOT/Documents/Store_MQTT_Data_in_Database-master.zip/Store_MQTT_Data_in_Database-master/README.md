# Store_MQTT_Data_in_Database

For detailed instruction please refer to the following link  - 

https://iotbytes.wordpress.com/store-mqtt-data-from-sensors-into-sql-database/

