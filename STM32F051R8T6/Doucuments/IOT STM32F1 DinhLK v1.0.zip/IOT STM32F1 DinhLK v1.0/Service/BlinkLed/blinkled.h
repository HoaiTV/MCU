
#ifndef __LED_H__
#define __LED_H__

VOID InitLed();
VOID InitLedFast();
VOID LedSet( BYTE nIndex);
VOID LedSetFast( BYTE nIndex1);
#endif /*LED_H_*/
