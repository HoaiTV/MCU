#ifndef CRC_H
#define CRC_H

#include <stdint.h>
#include <stddef.h>

uint8_t crc7(uint8_t *buffer, size_t len);

#endif // CRC_H
