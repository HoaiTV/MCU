//------------------------------------------------------------------------
// $Id
// 
// Copyright (C), 2004-2010, Centerm Information Co.,Ltd,All Rights Reserved
//
// FileName: driver_usart1.c 
//
// Author: wangpeng
//
// Version: 1.0
//
// Date: 2012-11-29
//
// Description: 
// 
// Function List: 
//
// History: 
//--------------------------------------------------------------------------


#ifndef __USART1_APP_H__
#define __USART1_APP_H__

#include "main.h"


#endif
