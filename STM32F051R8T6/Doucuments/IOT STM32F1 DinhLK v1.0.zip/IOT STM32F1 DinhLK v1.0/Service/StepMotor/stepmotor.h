
#ifndef __STEPMOTOR_H__
#define __STEPMOTOR_H__

VOID InitStepMotor();
VOID StepMotorProcess(PVOID pDATA);
#endif /*STEPMOTOR_H_*/
