
#ifndef __MINISTM32_PB_H__
#define	__MINISTM32_PB_H__

void PushButton_Config(void);


#endif	//__MINISTM32_PB_H__

