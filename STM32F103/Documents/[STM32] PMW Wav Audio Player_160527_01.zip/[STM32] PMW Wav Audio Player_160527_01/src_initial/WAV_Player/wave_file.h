#ifndef _WAVE_FILE
#define _WAVE_FILE

#include "integer.h"

#define READ_BUFF_SIZE	256

UINT play_wave_file(const char *fn);


#endif	// _WAVE_FILE
